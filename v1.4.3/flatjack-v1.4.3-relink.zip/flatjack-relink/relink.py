# Adds FlatJack's object files (objects/<env>/) to the program, after the libraries' objects
# as in a normal build.
Import("env")
import glob, os
objs = sorted(glob.glob(os.path.join(env.subst("$PROJECT_DIR"), "objects", env.subst("$PIOENV"), "*.o")))
assert objs, "no objects for " + env.subst("$PIOENV")
deps = env.ProcessProjectDeps  # adds the libraries' objects, then src/'s


def process_project_deps(e):
    deps()
    e.Append(PIOBUILDFILES=[e.File(o) for o in objs])


env.AddMethod(process_project_deps, "ProcessProjectDeps")
