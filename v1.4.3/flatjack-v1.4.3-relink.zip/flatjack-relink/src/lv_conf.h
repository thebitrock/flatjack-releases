// LVGL 9 settings for the on-board display (waveshare-s3 env only); the rest are LVGL's defaults.
#ifndef LV_CONF_H
#define LV_CONF_H
#define LV_COLOR_FORMAT_DEFAULT LV_COLOR_FORMAT_RGB565
// LVGL's own heap, a pool in PSRAM: with malloc its many small blocks (under 4 KB) took internal
// RAM, which the panel's bounce buffers need.
#define LV_USE_STDLIB_MALLOC  LV_STDLIB_BUILTIN
#define LV_MEM_SIZE (512 * 1024)
#define LV_MEM_POOL_INCLUDE <esp32-hal-psram.h>
#define LV_MEM_POOL_ALLOC ps_malloc
#define LV_USE_STDLIB_STRING  LV_STDLIB_CLIB
#define LV_USE_STDLIB_SPRINTF LV_STDLIB_CLIB   // %f in lv_label_set_text_fmt
#define LV_USE_QRCODE 1
#define LV_DEF_REFR_PERIOD 40
#define LV_FONT_MONTSERRAT_14 0
#define LV_FONT_CUSTOM_DECLARE LV_FONT_DECLARE(f40) LV_FONT_DECLARE(f60) LV_FONT_DECLARE(f110)
#define LV_FONT_MONTSERRAT_48 1  // only for its icons (LV_SYMBOL_*) in the navigation rail
#define LV_FONT_DEFAULT &f40
#define LV_USE_ASSERT_NULL 0
#define LV_USE_ASSERT_MALLOC 0
#endif
