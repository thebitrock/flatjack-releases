// FlatJack's code is in objects/. The includes below only tell PlatformIO which libraries to build.
#if 0
#include <Arduino.h>
#include <ArduinoJson.h>
#include <AsyncJson.h>
#include <BLEDevice.h>
#include <ESPAsyncWebServer.h>
#include <ESPmDNS.h>
#include <FS.h>
#include <HTTPClient.h>
#include <LittleFS.h>
#include <NetworkClientSecure.h>
#include <Preferences.h>
#include <Update.h>
#include <WiFi.h>
#include <WiFiManager.h>  // pulls http_parser: qualify HTTP_GET/POST below
#include <Wire.h>
#include <driver/gpio.h>
#include <driver/twai.h>
#include <espMqttClient.h>
#include <esp_app_desc.h>
#include <esp_app_format.h>
#include <esp_attr.h>
#include <esp_core_dump.h>
#include <esp_heap_caps.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_panel_rgb.h>
#include <esp_mac.h>
#include <esp_memory_utils.h>
#include <esp_system.h>
#include <esp_task_wdt.h>
#include <lvgl.h>
#include <math.h>
#include <mbedtls/platform.h>
#include <src/core/lv_obj_private.h>  // recolor(): an object's own styles
#include <src/core/lv_obj_style_private.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#endif
